import React from 'react';
import '../cssmodule/showcase.css';


const Showcase=()=>{

    return(
        
<div class='showcase-1'>
<img src='https://thumbs.dreamstime.com/b/artist-collector-exchanging-nft-cryptoart-blockchain-214492894.jpg'/>

</div>

        

    );

}

export default Showcase;