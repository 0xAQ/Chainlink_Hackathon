import React from 'react' ;
import '../cssmodule/Header.css';

const  Header=()=>{

    return (
    <div class='nav-bar'>

        <h3 className='nft-logo'>NFT-CHARTER</h3>

        <button class='btn'>button-1</button>
        <button class='btn'>button-1</button>
        <button class='btn'>button-1</button> 
        <button class='btn btn-r'>button-1</button> 

    </div>
    );
    

}


export default Header;