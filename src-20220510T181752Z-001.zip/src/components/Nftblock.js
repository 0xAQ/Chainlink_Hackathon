import React from 'react';
import '../cssmodule/Nftblock.css';

const Nftblock=(props)=>{

return(
    <div className='nft'>
        <img src={props.src}/>
        <div id='nft-img'></div>
        <div class='subblock'>
            <h2>{props.heading}</h2>
            <p>{props.para}</p>
        </div>
        
    </div>
);

}


export default Nftblock;
