import React from 'react';
import Header from './components/Header';
import Nftmodule from './components/Nftmodule';
import Showcase from './components/Showcase';


function App() {


  return (
    <div>
      
      <Header/>      
      <Showcase/>
      <Nftmodule></Nftmodule>
      
    </div>
         
   
  );


}

export default App;
